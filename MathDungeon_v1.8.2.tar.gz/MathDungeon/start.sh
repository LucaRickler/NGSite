#!/bin/bash
#Napsy Games (napsygames.com)
#MathDungeon

# Package info
declare -r VERSION="1.8.2"
declare -r GAME_NAME="MathDungeon"
declare -r PACKAGE_NAME="napsygames-mathdungeon"

# Global
declare -r CURRENT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Initialization
cd "${CURRENT_DIR}"

# Actions
execute_game() {
  local bin_32="${1}" 
  local bin_64="${2}"
  local bin_path32="${3}"
  local bin_path64="${4}"
  local lib_path32="${5}"
  local lib_path64="${6}"
  local arch=$(uname -m)
  if [ "$arch" == "x86_64" ]
  then
    export LD_LIBRARY_PATH="$LD_LIBRARY_PATH:$lib_path64"
    cd "${bin_path64}"
    ./"${bin_64}"
  else
    export LD_LIBRARY_PATH="$LD_LIBRARY_PATH:$lib_path32"
    cd "${bin_path32}"
    ./"${bin_32}"
 fi   
}

run_game() {
	echo "Running ${GAME_NAME} ${VERSION}"
	local bin32_name="MathDungeon.x86"
	local bin64_name="MathDungeon.x86_64"
	local bin_path32="$CURRENT_DIR/game"
	local bin_path64="$CURRENT_DIR/game"
	local lib_path32="$CURRENT_DIR/game"
	local lib_path64="$CURRENT_DIR/game"
	execute_game "${bin32_name}" "${bin64_name}" "${bin_path32}" "${bin_path64}" "${lib_path32}" "${lib_path64}"
}

#Main
run_game
